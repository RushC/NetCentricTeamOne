addEventListener("load", function() {
    parent.document.getElementById("sframe").contentDocument.location = "/Services/side.html";
});
