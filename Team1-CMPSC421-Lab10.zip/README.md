# Net-Centric Computing Course Website

######Created by Caleb Rush, Matt Downey, and Nick Totolos

#Screenshots

![](Screenshots/About1.PNG)

![](Screenshots/Clock1.gif)

![](Screenshots/Syllabus1.gif)

![](Screenshots/Evaluation1.gif)

![](Screenshots/Schedule1.PNG)

![](Screenshots/Animation1.gif)

![](Screenshots/LectureNotes1.gif)
