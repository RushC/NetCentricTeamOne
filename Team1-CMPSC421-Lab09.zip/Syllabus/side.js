$(document).ready(function() {
   // Animate the side div in.
    $("#sideDiv").hide().fadeIn();
});